/** Automatically generated file. DO NOT MODIFY */
package com.wzm.ticket.activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}